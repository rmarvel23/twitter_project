class DataError(Exception):
    """Exception raised for errors during data processing and cleaning."""
    pass

class RemoveError(Exception):
    """Exception raised for errors in the removing data processing"""
    pass

class VisualizationError(Exception):
    """Exception raised for errors in the visualization and calculating data processing"""
    pass

class TokenizeError(Exception):
    """Exception raised for errors in the tokenization process"""
    pass

class DataFrameError(Exception):
    """Exception raised when a DataFrame is needed but user gives other type object"""
    pass
