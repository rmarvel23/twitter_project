from abc import ABC, abstractmethod
import matplotlib.pyplot as plt
import seaborn as sns
from twitter_project.exceptions import VisualizationError


class DataVisualizer(ABC):
    """
    Abstract base class for data visualization and calculation.

    Attributes:
    ----------
    df (DataFrame): The DataFrame containing the data to visualize.
    """
    def __init__(self, df):
        """
        Initializes a Data Visualizer object

        Parameters
        ----------
        df (DataFrame): The DataFrame containing the data to visualize.
        """
        self.df = df

    @abstractmethod
    def get_positive(self, *param):
        """
        Abstract method to get visualization related to positive sentiment.

        Parameters
        ----------
        *param: Variable-length argument list.

        """
        pass

    @abstractmethod
    def get_negative(self, *param):
        """
        Abstract method to get visualization related to negative sentiment.

        Parameters
        ----------
        *param: Variable-length argument list.

        """
        pass

    @abstractmethod
    def get_sentiment(self, *param):
        """
        Abstract method to compare info by sentiment.

        Parameters
        ----------
        *param: Variable-length argument list.

        """
        pass


class CountryAnalyzer(DataVisualizer):
    """
    Subclass of DataVisualizer for analyzing sentiment by country.

    Parameters:
    -------
    df: pandas.DataFrame
        The DataFrame to be analyzed.

    Attributes:
    -------
    available_countries (list): List of available country names for analysis.
    """
    available_countries = ['Albania', 'Algeria', 'Andorra', 'Antigua and Barbuda',
                           'Argentina', 'Armenia', 'Australia', 'Austria', 'Bahamas',
                           'Bahrain', 'Bangladesh', 'Barbados', 'Benin', 'Bhutan',
                           'Bosnia and Herzegovina', 'Botswana', 'Brazil', 'Brunei',
                           'Burkina Faso', 'Burundi', "Côte d'Ivoire", 'Cabo Verde',
                           'Cambodia', 'Cameroon', 'Canada', 'Central African Republic',
                           'China', 'Comoros', 'Croatia', 'Cuba', 'Denmark', 'Djibouti',
                           'Dominican Republic', 'Ecuador', 'El Salvador',
                           'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Fiji',
                           'Finland', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana',
                           'Greece', 'Grenada', 'Guatemala', 'Guinea-Bissau', 'Guyana',
                           'Honduras', 'Hungary', 'India', 'Indonesia', 'Iraq', 'Ireland',
                           'Israel', 'Italy', 'Japan', 'Jordan', 'Kenya', 'Kiribati',
                           'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 'Lebanon', 'Lesotho',
                           'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Malaysia',
                           'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Mauritania',
                           'Mexico', 'Micronesia', 'Monaco', 'Montenegro', 'Morocco',
                           'Mozambique', 'Nepal', 'Nicaragua', 'Niger', 'North Korea',
                           'North Macedonia', 'Norway', 'Pakistan', 'Palau',
                           'Palestine State', 'Panama', 'Papua New Guinea', 'Paraguay',
                           'Philippines', 'Portugal', 'Rwanda', 'Saint Lucia',
                           'Saint Vincent and the Grenadines', 'Samoa',
                           'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Serbia',
                           'Seychelles', 'Sierra Leone', 'Singapore', 'Slovenia', 'Somalia',
                           'South Korea', 'South Sudan', 'Spain', 'Sri Lanka', 'Sudan',
                           'Suriname', 'Sweden', 'Switzerland', 'Syria', 'Tajikistan',
                           'Tanzania', 'Thailand', 'Timor-Leste', 'Togo', 'Tonga',
                           'Trinidad and Tobago', 'Tunisia', 'Turkmenistan', 'Tuvalu',
                           'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom',
                           'United States of America', 'Uruguay', 'Uzbekistan', 'Vanuatu',
                           'Venezuela', 'Yemen', 'Zambia', 'Zimbabwe', 'Afghanistan',
                           'Angola', 'Azerbaijan', 'Belgium', 'Belize', 'Bolivia', 'Bulgaria',
                           'Chad', 'Chile', 'Costa Rica', 'Cyprus', 'Dominica', 'Egypt',
                           'France', 'Haiti', 'Iceland', 'Jamaica', 'Madagascar', 'Malawi',
                           'Namibia', 'Nauru', 'Netherlands', 'New Zealand', 'Nigeria',
                           'Oman', 'Poland', 'Qatar', 'Russia', 'Saint Kitts and Nevis',
                           'San Marino', 'Slovakia', 'Solomon Islands', 'South Africa',
                           'Turkey', 'Vietnam', 'Belarus', 'Colombia', 'Guinea', 'Holy See',
                           'Kazakhstan', 'Moldova', 'Mongolia', 'Peru', 'Romania', 'Iran',
                           'Mauritius', 'Liberia', 'Eswatini']

    def __init__(self, df):
        """
        Initializes a CountryAnalyzer object.

        Parameters:
        -------
        df: pandas.DataFrame
            The DataFrame to be analyzed.
        """

        super().__init__(df)

    def get_positive(self, country):
        """
        Retrieves and displays the number of positive tweets for a given country.

        Parameters
        ----------
        country : str
            The name of te country to analyze

        Returns
        -------
        result: str
            The number of positive tweets in chosen country

        """
        while country not in self.available_countries:
            country = input(
                f"Country not available. The available list is: {self.available_countries}, please try again: ")
        try:
            result = self.df[(self.df['Country'] == country) & (self.df['sentiment'] == "positive")].shape[0]
            print(f"The are {result} results with positive tweets in {country}")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {country}: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing positive sentiment for {country}: {e}")

    def get_negative(self, country):
        """
        Retrieves and displays the number of negative tweets for a given country.

        Parameters
        ----------
        country : str
            The name of te country to analyze

        Returns
        -------
        result: str
            The number of positive tweets in chosen country

        """
        while country not in self.available_countries:
            country = input(
                f"Country not available. The available list is: {self.available_countries}, please try again: ")
        try:
            result = self.df[(self.df['Country'] == country) & (self.df['sentiment'] == "negative")].shape[0]
            print(f"The are {result} results with negative tweets in {country}")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {country}: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing negative sentiment for {country}: {e}")

    def get_sentiment(self, country):
        """
        Visualize sentiment distribution for a specific country.

        Parameters
        ----------
        country: str
            The name of the country to analyze.

        Returns
        -------
        A pie chart showing sentiment distribution

        """
        while country not in self.available_countries:
            country = input(
                f"Country not available. The available list is: {self.available_countries}, please try again: ")
        try:
            sentiment_counts = self.df[self.df['Country'] == country].groupby('sentiment').size()
            plt.figure(figsize=(8, 8))
            plt.pie(sentiment_counts, labels=sentiment_counts.index, autopct='%1.1f%%', startangle=140)
            plt.title(f'Tweets by people from {country}')
            plt.axis('equal')
            plt.show()
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {country}: {e}")
        except Exception as e:
            raise VisualizationError(f"Error plotting sentiment for {country}: {e}")

    def compare_sentiment(self, sentiment="negative"):
        """
        Compare sentiment distribution across different countries.

        Parameters
        ----------
        sentiment (str, optional)
            The sentiment type to compare (default is "negative")

        Returns
        -------
        Shows a bar chart of sentiment distribution across countries.

        """
        try:
            tweets_by_country = self.df[self.df['sentiment'] == sentiment]['Country'].value_counts()
            top_countries = tweets_by_country.head(20).sort_values(ascending=False)
            plt.figure(figsize=(10, 8))

            palette = sns.color_palette("tab20", len(top_countries))

            plt.bar(top_countries.index, top_countries.values, color=palette)
            plt.title(f'Top 20 countries with {sentiment} tweets')
            plt.xticks(rotation=45, ha='right', fontsize=7)
            plt.show()
        except VisualizationError as e:
            print(f"VisualizationError: {e}. Make sure 'sentiment' and 'Country' columns exist in the DataFrame.")


class AgeAnalyzer(DataVisualizer):
    """
    Subclass of DataVisualizer for analyzing sentiment by age.

    Parameters:
    -------
    df: pandas.DataFrame
        The DataFrame to be analyzed.

    Attributes:
    -------
    available_ages (list): List of available country ages for analysis.
    """
    available_ages = ['21-30', '31-45', '46-60', '70-100', '0-20', '60-70']

    def __init__(self, df):
        """
        Initializes a AgeAnalyzer object.

        Parameters:
        -------
        df: pandas.DataFrame
            The DataFrame to be analyzed.
        """
        super().__init__(df)

    def get_positive(self, age):
        """
            Retrieves and displays the number of positive tweets for a given age range.

            Parameters
            ----------
            age : str
                The age range to analyze

            Returns
            -------
            result: str
                The number of positive tweets in chosen age range

                """
        while age not in self.available_ages:
            age = input(f"Age range not available. Available ages are {self.available_ages}. Try again.")
        try:
            result = self.df[(self.df['Age'] == age) & (self.df['sentiment'] == "positive")].shape[0]
            print(f"The are {result} results with positive tweets with {age} years old")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {age} age: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing positive sentiment for {age} age: {e}")

    def get_negative(self, age):
        """
        Retrieves and displays the number of negative tweets for a given age range.

        Parameters
        ----------
        age range : str
            The age range to analyze

        Returns
        -------
        result: str
            The number of positive tweets in chosen age range

        """
        while age not in self.available_ages:
            age = input(f"Age range not available. Available ages are {self.available_ages}. Try again.")

        try:
            result = self.df[(self.df['Age'] == age) & (self.df['sentiment'] == "negative")].shape[0]
            print(f"The are {result} results with negative tweets with {age} years old")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {age} age: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing positive sentiment for {age} age: {e}")

    def get_sentiment(self, age):
        """
        Visualize sentiment distribution for a specific age range.

        Parameters
        ----------
        age: str
            The age range to analyze.

        Returns
        -------
        A pie chart showing sentiment distribution

        """

        while age not in self.available_ages:
            age = input(f"Age range not available. Available ages are {self.available_ages}. Try again.")

        try:
            sentiment_counts = self.df[self.df['Age'] == age].groupby('sentiment').size()
            plt.figure(figsize=(8, 8))
            plt.pie(sentiment_counts, labels=sentiment_counts.index, autopct='%1.1f%%', startangle=140)
            plt.title(f'Tweets by people of {age} years old')
            plt.axis('equal')
            plt.show()
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {age} years: {e}")
        except Exception as e:
            raise VisualizationError(f"Error plotting sentiment for {age} years: {e}")

    def compare_sentiment(self, sentiment="negative"):
        """
        Compare sentiment distribution across different ages.

        Parameters
        ----------
        sentiment(str, optional)
            The sentiment type to compare(default is negative)

        Returns
        -------
        Displays a bar chart comparing sentiment distribution across different ages.

        """
        try:
            tweets_by_age = self.df[self.df['sentiment'] == sentiment]['Age'].value_counts()
            top_ages = tweets_by_age.head(20).sort_values(ascending=False)
            plt.figure(figsize=(10, 8))

            palette = sns.color_palette("tab20", len(top_ages))

            plt.bar(top_ages.index, top_ages.values, color=palette)
            plt.title(f'Top ages with {sentiment} tweets')
            plt.xticks(rotation=45, ha='right', fontsize=7)

            plt.show()
        except VisualizationError as e:
            print(f"KeyError: {e}. Make sure 'sentiment' and 'Age' columns exist in the DataFrame.")


class TimeAnalyzer(DataVisualizer):
    """
    Subclass of DataVisualizer for analyzing sentiment by time.

    Parameters:
    -------
    df: pandas.DataFrame
        The DataFrame to be analyzed.

    Attributes:
    -------
    available_times (list): List of available country times for analysis.
    """
    available_times = ['noon', 'night', 'morning']

    def __init__(self, df):
        """
        Initialize TimeAnalyzer with a DataFrame.

        Parameters:
        -----------
        df : pandas.DataFrame
            The DataFrame containing the data for time analysis.
        """
        super().__init__(df)

    def get_positive(self, time):
        """
        Retrieves and displays the number of positive tweets for a given time.

        Parameters
        ----------
        time : str
            The time to analyze

        Returns
        -------
        result: str
            The number of positive tweets in chosen time"""

        while time not in self.available_times:
            time = input(f"Time of tweet not available. Available times are {self.available_times}. Try again.")
        try:
            result = self.df[(self.df['Time'] == time) & (self.df['sentiment'] == "positive")].shape[0]
            print(f"The are {result} results with positive tweets during {time}")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {time}: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing positive sentiment for {time}: {e}")

    def get_negative(self, time):
        """
        Retrieves and displays the number of negative tweets for a given time.

        Parameters
        ----------
        time : str
            The time to analyze

        Returns
        -------
        result: str
        The number of negative tweets in chosen time

                """
        while time not in self.available_times:
            time = input(f"Time of tweet not available. Available times are {self.available_times}. Try again.")
        try:
            result = self.df[(self.df['Time'] == time) & (self.df['sentiment'] == "negative")].shape[0]
            print(f"The are {result} results with negative tweets during {time}")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {time}: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing negative sentiment for {time}: {e}")

    def get_sentiment(self, time):
        """
        Visualize sentiment distribution for a specific time.

        Parameters
        ----------
        time: str
            The time to analyze.

        Returns
        -------
        Displays a pie chart showing sentiment distribution for the chosen time.

        """
        while time not in self.available_times:
            time = input(f"Time of tweet not available. Available times are {self.available_times}. Try again.")
        try:
            sentiment_counts = self.df[self.df['Time'] == time].groupby('sentiment').size()
            plt.figure(figsize=(8, 8))
            plt.pie(sentiment_counts, labels=sentiment_counts.index, autopct='%1.1f%%', startangle=140)
            plt.title(f'Tweets by people at {time}')
            plt.axis('equal')
            plt.show()
        except KeyError as e:
            raise VisualizationError(f"Error accessing data for {time}: {e}")
        except Exception as e:
            raise VisualizationError(f"Error plotting sentiment for {time}: {e}")

    def compare_sentiment(self, sentiment="negative"):
        """
        Compare sentiment distribution across different times.

        Parameters
        ----------
        sentiment(str, optional)
            The sentiment type to compare (default is "negative")

        Returns
        -------
        Displays a bar chart comparing sentiment distribution across different times.

        """
        try:
            tweets_by_time = self.df[self.df['sentiment'] == sentiment]['Time'].value_counts()
            top_times = tweets_by_time.sort_values(ascending=False)
            plt.figure(figsize=(10, 8))

            palette = sns.color_palette("tab20", len(top_times))
            plt.bar(top_times.index, top_times.values, color=palette)
            plt.title(f'{sentiment} tweets at different times ')
            plt.xticks(rotation=45, ha='right', fontsize=7)

            plt.show()
        except VisualizationError as e:
            print(f"KeyError: {e}. Make sure 'sentiment' and 'Time' columns exist in the DataFrame.")


class LengthAnalyzer(DataVisualizer):
    """
    Subclass of DataVisualizer for analyzing sentiment by Tweet Length.

    Parameters:
    -------
    df: pandas.DataFrame
        The DataFrame to be analyzed.

    """

    def __init__(self, df):
        """
        Initialize LengthAnalyzer with a DataFrame.

        Parameters:
        -----------
        df : pandas.DataFrame
            The DataFrame containing the data for length analysis.
        """
        super().__init__(df)

    def get_positive(self):
        """
        Calculates and displays the average length of positive tweets.

        Returns
        -------
        Mean: int
            Displays the average length of positive tweets.

        """

        try:
            positive_tweets = self.df[self.df['sentiment'] == "positive"]
            positive_lengths = positive_tweets['text'].apply(len)
            mean_length = positive_lengths.mean()
            result = round(mean_length)
            print(f"The mean length of positive tweets is {result}")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data: {e}")
        except Exception as e:
            raise VisualizationError(f"Error calculating mean length of positive tweets: {e}")

    def get_negative(self):
        """
        Calculates and displays the average length of negative tweets.

        Returns
        -------
        Mean: int
            Displays the average length of negative tweets.

        """
        try:
            negative_tweets = self.df[self.df['sentiment'] == "negative"]
            negative_lengths = negative_tweets['text'].apply(len)
            mean_length = negative_lengths.mean()
            result = round(mean_length)
            print(f"The mean length of negative tweets is {result}")
        except KeyError as e:
            raise VisualizationError(f"Error accessing data: {e}")
        except Exception as e:
            raise VisualizationError(f"Error calculating mean length of negative tweets: {e}")

    def get_sentiment(self):
        """
        Visualizes the average tweet length for different sentiments.

        Returns
        -------
        Displays a bar chart showing the average tweet length for positive,
        negative and neutral tweets.

        """
        try:
            sentiments = ["positive", "negative", "neutral"]
            mean_lengths = []

            for sentiment in sentiments:
                tweet_lengths = self.df[self.df['sentiment'] == sentiment]['text'].apply(len)
                mean_length = tweet_lengths.mean()
                mean_lengths.append(mean_length)

            plt.figure(figsize=(10, 6))
            plt.bar(sentiments, mean_lengths, color=['green', 'red', 'blue'])
            plt.xlabel('Sentiment')
            plt.ylabel('Average Tweet Length')
            plt.title('Average Tweet Length by Sentiment')
            plt.show()
        except KeyError as e:
            raise VisualizationError(f"Error accessing data: {e}")
        except Exception as e:
            raise VisualizationError(f"Error plotting tweet length by sentiment: {e}")


class SpecificDataAnalyzer(DataVisualizer):
    """
    Subclass of DataVisualizer for analyzing sentiment and get specific
    data about who wrote the negative, neutral and positive tweets analyzed.

    Parameters:
    -------
    df: pandas.DataFrame
        The DataFrame to be analyzed.

      """
    def __init__(self, df):
        """
        Initialize SpecificDataAnalyzer with a DataFrame

        Parameters
        ----------
        df: pandas.DataFrame
            The DataFrame containing the data for specific data analysis.
        """
        super().__init__(df)

    def get_negative(self):
        """
        Finds and displays information related to the most negative tweets.

        Returns
        -------
        Displays the country, age category, time and tweet length most
        repeated in negative tweets.

        """
        try:
            negative_tweets = self.df[self.df['sentiment'] == 'negative']
            most_negative_info = negative_tweets.groupby(
                ['Country', 'Age Category', 'Time', 'Tweet Length']).size().idxmax()
            print(most_negative_info)

        except KeyError as e:
            raise VisualizationError(f"Error accessing data for most negative tweets: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing most negative tweets: {e}")

    def get_positive(self):
        """
        Finds and displays information related to the most positive tweets.

        Returns
        -------
        Displays the country, age category, time and tweet length most
        repeated in positive tweets.
        """
        try:
            positive_tweets = self.df[self.df['sentiment'] == 'positive']
            most_positive_info = positive_tweets.groupby(
                ['Country', 'Age Category', 'Time', 'Tweet Length']).size().idxmax()
            print(most_positive_info)

        except KeyError as e:
            raise VisualizationError(f"Error accessing data for most positive tweets: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing most positive tweets: {e}")

    def get_sentiment(self):
        """
        Retrieves and displays the most frequent sentiment information (negative,
        positive and neutral) by country, age category, time and tweet legth.

        Returns
        -------
        Prints the top 10 records of most frequent sentiment information for negative, positive, and neutral sentiments.

        """
        try:
            negative_tweets = self.df[self.df['sentiment'] == 'negative']
            negative_counts = negative_tweets.groupby(['Country', 'Age Category', 'Time', "Tweet Length"]).size()
            top_negative_info = negative_counts.nlargest(10).reset_index()
            top_negative_info.columns = ['Country', 'Age', 'Time', 'Length', 'Count Negative']

            positive_tweets = self.df[self.df['sentiment'] == 'positive']
            positive_counts = positive_tweets.groupby(['Country', 'Age Category', 'Time', 'Tweet Length']).size()
            top_positive_info = positive_counts.nlargest(10).reset_index()
            top_positive_info.columns = ['Country', 'Age', 'Time', 'Length', 'Count Positive']

            neutral_tweets = self.df[self.df['sentiment'] == 'neutral']
            neutral_counts = neutral_tweets.groupby(['Country', 'Age Category', 'Time', 'Tweet Length']).size()
            top_neutral_info = neutral_counts.nlargest(10).reset_index()
            top_neutral_info.columns = ['Country', 'Age', 'Time', 'Length', 'Count Neutral']

            print("Negative information: ")
            print(top_negative_info.to_string(index=False))

            print("\nPositive information: ")
            print(top_positive_info.to_string(index=False))

            print("\nNeutral information: ")
            print(top_neutral_info.to_string(index=False))

        except KeyError as e:
            raise VisualizationError(f"Error accessing data for sentiment analysis: {e}")
        except Exception as e:
            raise VisualizationError(f"Error processing sentiment analysis: {e}")
