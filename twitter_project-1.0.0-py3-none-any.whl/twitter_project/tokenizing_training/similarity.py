from twitter_project.tokenizing_training.tokenizing import filter_words
from twitter_project.exceptions import DataFrameError
from nltk.tokenize import word_tokenize
from gensim.models import Word2Vec
import pandas as pd
import nltk
nltk.download('punkt')
nltk.download('stopwords')


class Word2VecProcessor:
    """
    A class to process tweets, train a Word2Vec model, get
    the similarity between two words and get synonyms.

    """
    def __init__(self, vector_size=150, window=10, min_count=10, workers=4, epochs=20):
        """
        Initialize the Word2VecProcessor class with different parameters.

        Parameters
        ----------
        vector_size : int, optional
            Dimensionality of the word vectors (default is 150)
        window : int, optional
            Maximum distance between the current and predicted word within a sentence (default is 10).
        min_count : int, optional
            Ignores all words with total frequency lower than this (default is 10).
        workers : int, optional
            Number of worker threads to train the model (default is 4).
        epochs : int, optional
            Number of iterations (epochs) over the corpus (default is 20).
                """
        self.__vector_size = vector_size
        self.__window = window
        self.__min_count = min_count
        self.__workers = workers
        self.__epochs = epochs
        self.__model = None

    @staticmethod
    def process_tweets(dataset):
        """
        Process tweets to generate a corpus for training Word2Vec

        Parameters
        ----------
        dataset : DataFrame
             A pandas DataFrame containing the tweets and the 'text' column
             to be processed.

        Returns
        -------
        corpus : list of list of str
            A list where each element is a list of cleaned tokens from a tweet

        """
        if not isinstance(dataset, pd.DataFrame):
            raise DataFrameError("You need to upload a DataFrame")

        try:
            corpus = []
            for text in dataset['text'].astype(str):
                tokens = word_tokenize(text.lower())
                cleaned_tokens = filter_words(tokens)
                corpus.append(cleaned_tokens)

            return corpus

        except Exception as e:
            print(f"Error processing tweets for Word2Vec: {e}")

    def train_model(self, corpus):
        """
        Train a Word2Vec model using the provided corpus

        Parameters
        ----------
        corpus: list of list of str
            A list where each element is a list of a cleaned tokens from a tweet


        """
        try:
            self.__model = Word2Vec(sentences=corpus, vector_size=self.__vector_size,
                                    window=self.__window, min_count=self.__min_count,
                                    workers=self.__workers, epochs=self.__epochs)
            print("Word2Vec model trained successfully.")

        except Exception as e:
            print(f"Error training Word2Vec model: {e}")

    def get_similarity(self, term1, term2):
        """
        Gets the similarity between two terms using the trained Word2Vec model

        Parameters
        ----------
        term1 : str
            The first term to compare.
        term2 : str
            The second term to compare.

        Returns
        -------
        similarity : str
            A message indicating the similarity score between the two terms.
            The similarity score goes between -1 and 1, being -1 very different words
            and 1 very similar words.

        """
        try:
            if self.__model is None:
                return "Model not initialized."

            if term1 not in self.__model.wv.key_to_index or term2 not in self.__model.wv.key_to_index:
                return f"One or both terms ('{term1}', '{term2}') are not in the vocabulary of the model."

            similarity = self.__model.wv.similarity(term1, term2)
            return f"Similarity between {term1} and {term2}: {similarity:.4f}"

        except Exception as e:
            return f"Error calculating similarity: {e}"

    def get_similar_word(self, term):
        """
        Gets the most similar words to a given term using the trained Word2Vec model.

        Parameters
        ----------
        term : str
            The term to find similar words for.

        Returns
        -------
        similar_words : list of tuple
            A list of tuple where each tuple contains a similar word and its similarity score.

        """
        try:
            if self.__model is None:
                return "Model not initialized."

            similar_words = self.__model.wv.most_similar(term)
            return similar_words

        except Exception as e:
            return f"Error finding similar words: {e}"
