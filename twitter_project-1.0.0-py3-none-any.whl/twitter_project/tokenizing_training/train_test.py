
from twitter_project.tokenizing_training.tokenizing import filter_words
from twitter_project.exceptions import DataFrameError
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.pipeline import Pipeline
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import nltk
import pandas as pd
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')


class SentimentClassifier:
    """
    A sentiment classifier that trains a model to predict sentiment from text data.

    Attributes
    ----------
    pipeline : sklearn.pipeline.Pipeline or None
        Pipeline containing the vectorizer and classifier.
    vectorizer : sklearn.feature_extraction.text.CountVectorizer
        CountVectorizer for converting text to vectors.

    Methods
    -------
    process_tweets(dataset):
        Processes a dataset of tweets to extract text and labels.
    train(all_texts, labels):
        Trains the sentiment classifier using the provided text and labels.
    predict_sentiment(text):
        Predicts the sentiment (positive, negative, neutral) of a given text.
    """
    def __init__(self):
        """
        Initializes the SentimentClassifier with an empty pipeline
        and CountVectorizer.
        """
        self.pipeline = None
        self.vectorizer = CountVectorizer()

    @staticmethod
    def process_tweets(dataset):

        """
        Processes a dataset of tweets to extract text and corresponding
        sentiment labels.

        Parameters
        ----------
        dataset : pandas.DataFrame
            DataFrame containing 'text' and 'sentiment' columns.

        Returns
        -------
        all_texts: list of str
            Preprocessed and lemmatized text from the dataset.
        labels: list of int
            Numeric labels corresponding to sentiment categories:
            0 (negative), 1 (positive), 2 (neutral).

        """
        if not isinstance(dataset, pd.DataFrame):
            raise DataFrameError("You need to upload a DataFrame")

        all_texts = []
        labels = []
        lemmatizer = WordNetLemmatizer()

        for index, row in dataset.iterrows():
            text = row['text']
            sentiment = row['sentiment']
            if isinstance(text, str):
                tokens = word_tokenize(text)
                cleaned_words = filter_words(tokens)
                lemmatized_words = [lemmatizer.lemmatize(word) for word in cleaned_words]
                all_texts.append(" ".join(lemmatized_words))
                if sentiment == 'positive':
                    labels.append(1)
                elif sentiment == 'negative':
                    labels.append(0)
                elif sentiment == 'neutral':
                    labels.append(2)
        return all_texts, labels

    def train(self, all_texts, labels):
        """
        Trains the sentiment classifier using the provided texts and labels.

        Parameters
        ----------
        all_texts: list of str
            Preprocessed and lemmatized text data.
        labels: list of int
            Corresponding sentiment labels: 0 (negative), 1 (positive), 2 (neutral).

        Returns
        -------

        """
        if not all_texts or not labels:
            raise ValueError("Empty data provided for training")

        X_train, X_test, y_train, y_test = train_test_split(all_texts, labels, test_size=0.2, random_state=42)

        param_grid = {
            'vect__ngram_range': [(1, 1), (1, 2)],
            'vect__max_features': [1000, 5000, None],
            'vect__min_df': [1, 5],
            'clf__alpha': [0.01, 1.0, 2.0, 5.0, 10.0],
            'clf__fit_prior': [True, False]
        }

        pipeline = Pipeline([
            ('vect', self.vectorizer),
            ('clf', MultinomialNB())
        ])

        grid_search = GridSearchCV(pipeline, param_grid, cv=5, scoring='accuracy')
        grid_search.fit(X_train, y_train)

        self.pipeline = grid_search.best_estimator_

        y_pred = self.pipeline.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted')
        recall = recall_score(y_test, y_pred, average='weighted')
        f1 = f1_score(y_test, y_pred, average='weighted')

        print(f"Best parameters: {grid_search.best_params_}")
        print(f"Accuracy: {accuracy}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall: {recall:.4f}")
        print(f"F1-score: {f1:.4f}")

    def predict_sentiment(self, text):
        """
        Predicts the sentiment (positive, negative, neutral) of the given text.

        Parameters
        ----------
        text: str
            Text for which sentiment prediction is to be made.

        Returns
        -------
        str
            Predicted sentiment category: 'Positive', 'Negative', or 'Neutral'.

        """
        if self.pipeline is None:
            raise ValueError("The model has not been trained yet. Please train the model first.")

        text_features = self.pipeline.named_steps['vect'].transform([text])

        prediction = self.pipeline.named_steps['clf'].predict(text_features)

        if prediction == 1:
            return "Positive"
        elif prediction == 0:
            return "Negative"
        elif prediction == 2:
            return "Neutral"
