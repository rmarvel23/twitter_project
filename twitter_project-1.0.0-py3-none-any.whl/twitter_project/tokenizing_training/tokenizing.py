from twitter_project.exceptions import DataFrameError
import re
import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter
from wordcloud import WordCloud

import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords


from twitter_project.exceptions import TokenizeError

nltk.download('punkt')
nltk.download('stopwords')


class AddData:
    """
    A class to add new data in order to have more vocabulary before tokenizing.

    Parameters
    ----------
    df : pandas.DataFrame
        The initial DataFrame to which new data will be added
    """
    def __init__(self, df):

        """
        Initialize the AddData class with an existing DataFrame

        Parameters
        ----------
        df : pandas.DataFrame
            The initial DataFrame to which new data will be added
        """
        if not isinstance(df, pd.DataFrame):
            raise DataFrameError("You need to upload a DataFrame")
        else:
            self.df = df

    @staticmethod
    def create_new_df():
        """
        Creates a new DataFrame with predefined text and sentiment data.

        Returns
        -------
        pandas.DataFrame
            A DataFrame containing sample text and sentiment data.

        """
        cols = ["text", "sentiment"]
        data = [["This Taylor Swift CD is great, I love it, OMG", "positive"],
                ["I hate this fucking shit, I feel so alone, nobody understands me", "negative"],
                ["Not bad, it is nice", "neutral"],
                ["Great!! See you tomorrow at cinema, we will have fun", "positive"],
                ["That asshole hit me in front of my friends, i will beat him until he loses his teeth", "negative"],
                ["Ok, no problem", "neutral"],
                ["Wow! It's incredible. I've never watched a movie like this, it's unique", "positive"],
                ["You're a berk, you daft cow and your bro is a dick too", "negative"],
                ["Sure. I will text you then. Bye", "neutral"]]
        df2 = pd.DataFrame(data, columns=cols)
        return df2

    def concat_data(self, new_df):
        """
        Concatenates the existing DataFrame with the new one.

        Parameters
        ----------
        new_df : pandas.DataFrame
            The new DataFrame to be concatenated with the existing one.

        Returns
        -------
        pandas.DataFrame
            A concatenated DataFrame containing the existing and new data.

        """
        if not isinstance(new_df, pd.DataFrame):
            raise DataFrameError("You need to upload a DataFrame")

        df = pd.concat([self.df, new_df])
        return df


def tokenize_text(text):
    """
    Tokenizes text into individual words.

    Parameters
    ----------
    text (str)
        Input text to be tokenized

    Returns
    -------
    list
        List of tokens (words) extracted from the input text.

    """
    return word_tokenize(text.lower())


def tokenize_sentiment(dataset, sentiment):
    """
    Tokenizes tweets based on sentiment category and creates a bag of words.

    Parameters
    ----------
    dataset (pandas.DataFrame)
        DataFrame containing 'text' and 'sentiment' columns.

    sentiment (str)

    Returns
    -------
    collections.Counter
        Bag of words (word frequencies) for the specified sentiment category.
    """
    try:
        filtered_tweets = dataset.loc[dataset['sentiment'] == sentiment].copy()
        filtered_tweets['text'] = filtered_tweets['text'].astype(str)
        filtered_tweets['tokens'] = filtered_tweets['text'].apply(tokenize_text)
        words = [word for tokens in filtered_tweets['tokens'] for word in tokens]
        bag_of_words = Counter(words)
        return bag_of_words
    except Exception as e:
        raise TokenizeError(f"Error creating bag of words for {sentiment} tweets: {e}")


def filter_words(words):
    """
    Filters out stopwords, non-alphabetic characters, short words
    and specific words that do not contribute to our analysis or thar
    do not have a useful meaning.

    Parameters
    ----------
    words (list)
        List of words to be filtered.

    Returns
    -------
    list
        Filtered list of words.

    """
    nm_words = ["her", "there", "back", "will", "still", "has", "what", "when", "time",
                "about", "know", "feel", "too", "don", "your", "much", "think",
                "this", "like", "with", "out", "even", "did", "them", "hrs", "one",
                "get", "got", "day", "give", "for", "from"]
    cleaned_words = []
    try:
        for w in words:
            w = w.lower()
            w = re.sub(r'@\w+|#', '', w)
            w = re.sub(r'[^a-z]', '', w)
            if w in stopwords.words("english"):
                continue
            elif w in nm_words:
                continue
            elif len(w) < 3:
                continue
            elif re.match(r'^https?', w) or re.match(r'^www', w) or re.match(r'^apps', w):
                continue
            else:
                cleaned_words.append(w)
        return cleaned_words
    except LookupError as e:
        print(f"LookupError: {e}. Make sure NLTK stopwords for 'english' are downloaded.")
        return []
    except Exception as e:
        print(f"Error in words_filtered: {e}")
        return []


def get_wordcloud(words):
    """
    Generates a word cloud visualization from a list of words.

    Parameters
    ----------
    words (list)
        List of words to visualize.

    Returns
    -------
    Displays the word cloud plot.

    """
    try:

        if len(words) == 0:
            print("Warning: Empty list of words provided. Cannot generate word cloud.")
            return
        words_join = " ".join(words)
        wordcloud = WordCloud(width=1000, height=500, relative_scaling=0.5).generate(words_join)
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.show()
    except ImportError as e:
        print(f"ImportError: {e}. Make sure 'wordcloud' and 'matplotlib' are installed.")
    except TypeError as e:
        print(f"TypeError: {e}")
    except Exception as e:
        print(f"Error in get_wordcloud: {e}")
