"""Top-level package for twitter_project."""

__author__ = "Rocio Martinez Veloso"
__email__ = "rmartinezveloso@alumnos.cei.es"
__version__ = "1.0.0"

PACKAGE_NAME = "twitter_project"