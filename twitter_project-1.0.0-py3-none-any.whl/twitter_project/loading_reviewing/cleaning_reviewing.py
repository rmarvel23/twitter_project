from twitter_project.exceptions import DataError, DataFrameError
import numpy as np
import pandas as pd


class DataCleaner:
    """
        A class used to clean a pandas DataFrame by dropping unnecessary columns,
        removing rows with null values in specified columns, and renaming columns.

        Attributes
        ----------
        df : pandas.DataFrame
            The DataFrame that is being cleaned.
        """

    def __init__(self, df):
        """
        Initializes the DataCleaner with the DataFrame to be cleaned.

        Parameters
        ----------
        df : pandas.DataFrame
            The DataFrame to be cleaned.
        """
        if not isinstance(df, pd.DataFrame):
            raise DataFrameError("You need to upload a DataFrame")
        else:
            self.df = df

    def drop_unnecessary_col(self):
        """
        Drops unnecessary columns from the DataFrame.

        The columns that we decided that are unnecessary
        for this project and that will be dropped are:
        - 'textID'
        - 'selected_text'
        - 'Population -2020'
        - 'Land Area (Km²)'
        - 'Density (P/Km²);;;;;;;;;;;;'

        Returns
        -------
        pandas.DataFrame
            The DataFrame with the unnecessary columns removed.

        Raises
        ------
        DataError
            If there is an error dropping the columns.
        """
        unnecessary_columns = ['textID', 'selected_text', 'Population -2020',
                               'Land Area (Km²)', 'Density (P/Km²);;;;;;;;;;;;']
        try:
            self.df = self.df.drop(columns=unnecessary_columns, errors='ignore')
            return self.df
        except KeyError as e:
            raise DataError(f"Error dropping columns: {e}")

    def remove_nulls(self):
        """
        Removes rows with null values in the remaining columns.

        These columns are:
        - 'sentiment'
        - 'Time of Tweet'
        - 'Age of User'
        - 'Country'
        - 'text'

        Returns
        -------
        pandas.DataFrame
            The DataFrame with rows containing null values in specified columns removed.

        Raises
        ------
        DataError
            If there is an error dropping the rows.
        """
        columns_to_check = ["sentiment", "Time of Tweet", "Age of User", "Country", "text"]
        try:
            self.df = self.df.dropna(subset=columns_to_check)
            return self.df
        except KeyError as e:
            raise DataError(f"Error dropping nulls: {e}")

    def rename_col(self):

        """
        Renames specified columns in the DataFrame in order to have
        shorter names.

        The columns renamed are:
        - 'Time of Tweet' to 'Time'
        - 'Age of User' to 'Age'

        Returns
        -------
        pandas.DataFrame
            The DataFrame with the specified columns renamed.

        Raises
        ------
        DataError
            If there is an error renaming the columns.
        """
        try:
            self.df = self.df.rename(columns={"Time of Tweet": "Time", "Age of User": "Age"})
            return self.df
        except KeyError as e:
            raise DataError(f"Error renaming columns: {e}")


class DataReviewer:
    """
    A class used to review and analyze a pandas DataFrame, providing various statistical
    summaries and information about the dataset.


    Attributes
    ----------
    df : pandas.DataFrame
        The DataFrame being reviewed.
    data_cleaner : DataCleaner
        An instance of DataCleaner used for cleaning operations on the DataFrame.
    """

    def __init__(self, df):
        """
        Initializes the DataReviewer with the DataFrame to be reviewed.

        Parameters
        ----------
        df : pandas.DataFrame
            The DataFrame to be reviewed.
        """
        if not isinstance(df, pd.DataFrame):
            raise DataFrameError("You need to upload a DataFrame")
        else:
            self.df = df
        self.data_cleaner = (
          DataCleaner(df))

    def show_sample(self, n=5):
        """
        Returns a random sample of the DataFrame.

        Parameters
        ----------
        n : int, optional
            Number of samples to return, by default 5.

        Returns
        -------
        pandas.DataFrame
            A random sample of the DataFrame.

        Raises
        ------
        DataError
            If there is an error getting the sample.
        """
        try:
            return self.df.sample(n)
        except Exception as e:
            raise DataError(f"Error showing sample: {e}")

    def add_length_category(self):
        """
        Adds a new column 'Tweet Length' based on the length of the 'text' column.

        'short' for tweets with length <= 50 characters,
        'medium' for tweets with length > 50 and <= 100 characters,
        'long' for tweets with length > 100 characters.

        Returns
        -------
        pandas.DataFrame
            The DataFrame with the new 'Tweet Length' column added.

        Raises
        ------
        DataError
            If there is an error adding the new column.
        """
        try:
            self.df["Tweet Length"] = np.where(self.df['text'].str.len() <= 50, 'short',
                                               np.where(self.df['text'].str.len() <= 100, 'medium', 'long'))
            return self.df
        except Exception as e:
            raise DataError(f"Error adding tweet length category: {e}")

    def add_age_categories(self):
        """
        Adds a new column 'Age Category' based on the 'Age' column.

        'child' for ages in the range '0-20',
        'young adult' for ages in the range '21-30',
        'adult' for ages in the range '31-45' and '46-60',
        'senior' for ages in the range '60-70' and '70-100'.

        Returns
        -------
        pandas.DataFrame
            The DataFrame with the new 'Age Category' column added.

        Raises
        ------
        DataError
            If there is an error adding the new column.
        """
        age_categories = ['child', 'young adult', 'adult', 'senior']
        try:
            self.df['Age Category'] = np.select(
                [
                    self.df['Age of User'].isin(['0-20']),
                    self.df['Age of User'].isin(['21-30']),
                    self.df['Age of User'].isin(['31-45', '46-60']),
                    self.df['Age of User'].isin(['60-70', '70-100'])
                ],
                age_categories,
                default='unknown'
            )
            return self.df
        except Exception as e:
            raise DataError(f"Error adding age categories: {e}")

    def get_info(self):
        """
        Returns a concise summary of the DataFrame.

        Returns
        -------
        str
            A concise summary of the DataFrame.

        Raises
        ------
        DataError
            If there is an error getting the DataFrame info.
        """
        try:
            return self.df.info()
        except Exception as e:
            raise DataError(f"Error showing sample: {e}")

    def describe(self):
        """
        Generates descriptive statistics of the DataFrame.

        Returns
        -------
        pandas.DataFrame
            Descriptive statistics of the DataFrame.

        Raises
        ------
        DataError
            If there is an error generating the descriptive statistics.
        """
        try:
            return self.df.describe()
        except Exception as e:
            raise DataError(f"Error showing sample: {e}")

    def get_columns(self):
        """
        Returns the column labels of the DataFrame.

        Returns
        -------
        pandas.Index
            The column labels of the DataFrame.

        Raises
        ------
        DataError
            If there is an error getting the columns.
        """
        try:
            return self.df.columns
        except Exception as e:
            raise DataError(f"Error showing sample: {e}")

    def count_rows(self, column):
        """
        Counts non-null values in a specified column of the DataFrame.

        Parameters
        ----------
        column : str
            The column name to count rows for.

        Returns
        -------
        int
            Number of non-null values in the specified column.

        Raises
        ------
        DataError
            If the specified column is not found in the DataFrame or if there is an error
            counting rows.
        """
        try:
            if column in self.df.columns:
                return self.df[column].count()
            else:
                raise DataError(f"Column '{column}' not found in dataset.")
        except Exception as e:
            raise DataError(f"Error counting rows: {e}")

    def get_unique(self, column):
        """
        Returns unique values in a specified column of the DataFrame.

        Parameters
        ----------
        column : str
            The column name to get unique values from.

        Returns
        -------
        numpy.ndarray
            Unique values in the specified column.

        Raises
        ------
        DataError
            If the specified column is not found in the DataFrame or if there is an error
            getting unique values.
        """
        try:
            if column in self.df.columns:
                return self.df[column].unique()
            else:
                raise DataError(f"Column '{column}' not found in dataset.")
        except Exception as e:
            raise DataError(f"Error getting unique values: {e}")

    def check_nulls(self):
        """
        Checks for null values in the DataFrame.

        Returns
        -------
        pandas.Series
        Boolean Series indicating whether each column has null values.

        Raises
        ------
        DataError
            If there is an error checking for null values.
        """
        try:
            return self.df.isnull().any()
        except Exception as e:
            raise DataError(f"Error checking nulls: {e}")

    def get_percentage_nulls(self):
        """
        Calculates the percentage of null values in each column of the DataFrame.

        Returns
        -------
        pandas.Series
            Series containing the percentage of null values for each column.

        Raises
        ------
        DataError
            If there is an error calculating the percentage of null values.
        """
        try:
            return self.df.isnull().sum() / len(self.df) * 100
        except Exception as e:
            raise DataError(f"Error checking nulls percentages: {e}")

    def get_dtypes(self):
        """
        Returns the data types of the columns in the DataFrame.

        Returns
        -------
        pandas.Series
            Series containing the data types of the columns.

        Raises
        ------
        DataError
            If there is an error getting the data types.
        """
        try:
            return self.df.dtypes
        except Exception as e:
            raise DataError(f"Error checking nulls: {e}")

    def shape(self):
        """
        Returns the shape of the DataFrame.

        Returns
        -------
        tuple
            A tuple representing the dimensions of the DataFrame (rows, columns).

        Raises
        ------
        DataError
            If there is an error getting the shape of the DataFrame.
        """
        try:
            return self.df.shape
        except Exception as e:
            raise DataError(f"Error getting shape: {e}")

    def count_unique(self, column):
        """
        Counts unique values in a specified column of the DataFrame.

        Parameters
        ----------
        column : str
            The column name to count unique values for.

        Returns
        -------
        int
            Number of unique values in the specified column.

        Raises
        ------
        DataError
            If the specified column is not found in the DataFrame or if there is an error
            counting unique values.
        """
        try:
            if column in self.df.columns:
                return self.df[column].nunique()
            else:
                raise DataError(f"Column '{column}' not found in dataset.")
        except Exception as e:
            raise DataError(f"Error counting unique values: {e}")
