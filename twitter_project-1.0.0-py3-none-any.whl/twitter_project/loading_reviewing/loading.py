import chardet
import pandas as pd


def check_encoding(file_csv):
    """
    Get the right encoding of the document.

    Parametersre
    ----------
    file_csv: str
        The csv document.

    Returns
    -------
    str
        The right encoding of the document

    """
    with open(file_csv, 'rb') as f:
        result = chardet.detect(f.read())
    return result['encoding']


def read_csv(csv, encoding):
    df = pd.read_csv(csv, encoding=encoding, sep=",", on_bad_lines='skip')
    return df
