from twitter_project.exceptions import RemoveError, DataFrameError
import pandas as pd


class WrongDataRemover:
    """
    A class used to remove invalid or wrong data from a pandas DataFrame based on specified criteria.

    Parameters
    ----------
    df : pandas.DataFrame
        The DataFrame containing the data to be cleaned.

    Attributes
    ----------
    df : pandas.DataFrame
        The DataFrame being cleaned.
    """
    def __init__(self, df):
        """
        Initializes the WrongDataRemover with the DataFrame to be cleaned.

        Parameters
        ----------
        df : pandas.DataFrame
            The DataFrame to be cleaned.
        """
        if not isinstance(df, pd.DataFrame):
            raise DataFrameError("You need to upload a DataFrame")
        else:
            self.df = df

    def remove_wrong_age(self):
        """
        Removes rows with invalid 'Age' values from the DataFrame.

        Valid 'Age' ranges:
        - "0-20"
        - "21-30"
        - "31-45"
        - "46-60"
        - "60-70"
        - "70-100"

        Returns
        -------
        pandas.DataFrame
            The DataFrame with rows containing valid 'Age' values.

        Raises
        ------
        RemoveError
            If there is an error removing rows based on 'Age' values.
        """
        valid_ranges = ["0-20", "21-30", "31-45", "46-60", "60-70", "70-100"]
        try:
            self.df = self.df[self.df['Age'].isin(valid_ranges)]
            return self.df
        except KeyError as e:
            raise RemoveError(f"Error removing wrong ages: {e}")

    def remove_wrong_time(self):
        """
        Removes rows with invalid 'Time' values from the DataFrame.

        Valid 'Time' values:
        - "noon"
        - "night"
        - "morning"

        Returns
        -------
        pandas.DataFrame
            The DataFrame with rows containing valid 'Time' values.

        Raises
        ------
        RemoveError
            If there is an error removing rows based on 'Time' values.
        """
        valid_times = ["noon", "night", "morning"]
        try:
            self.df = self.df[self.df['Time'].isin(valid_times)]
            return self.df
        except KeyError as e:
            raise RemoveError(f"Error removing wrong times: {e}")

    def remove_wrong_countries(self):
        """
        Removes rows with invalid 'Country' values from the DataFrame.

        Valid 'Country' values:
        - List of valid country names.

        Returns
        -------
        pandas.DataFrame
            The DataFrame with rows containing valid 'Country' values.

        Raises
        ------
        RemoveError
            If there is an error removing rows based on 'Country' values.
        """
        valid_countries = ['Albania', 'Algeria', 'Andorra', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Australia',
                           'Austria', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Benin', 'Bhutan',
                           'Bosnia and Herzegovina', 'Botswana', 'Brazil', 'Brunei', 'Burkina Faso', 'Burundi',
                           "Côte d'Ivoire", 'Cabo Verde', 'Cambodia', 'Cameroon', 'Canada', 'Central African Republic',
                           'China', 'Comoros', 'Croatia', 'Cuba', 'Czechia (Czech Republic)',
                           'Democratic Republic of the Congo', 'Denmark', 'Djibouti', 'Dominican Republic', 'Ecuador',
                           'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Fiji', 'Finland',
                           'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Greece', 'Grenada', 'Guatemala',
                           'Guinea-Bissau', 'Guyana', 'Honduras', 'Hungary', 'India', 'Indonesia', 'Iraq', 'Ireland',
                           'Israel', 'Italy', 'Japan', 'Jordan', 'Kenya', 'Kiribati', 'Kuwait', 'Kyrgyzstan', 'Laos',
                           'Latvia', 'Lebanon', 'Lesotho', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg',
                           'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Mauritania', 'Mexico',
                           'Micronesia', 'Monaco', 'Montenegro', 'Morocco', 'Mozambique', 'Myanmar (formerly Burma)',
                           'Nepal', 'Nicaragua', 'Niger', 'North Korea', 'North Macedonia', 'Norway', 'Pakistan',
                           'Palau', 'Palestine State', 'Panama', 'Papua New Guinea', 'Paraguay', 'Philippines',
                           'Portugal', 'Rwanda', 'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa',
                           'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Serbia', 'Seychelles', 'Sierra Leone',
                           'Singapore', 'Slovenia', 'Somalia', 'South Korea', 'South Sudan', 'Spain', 'Sri Lanka',
                           'Sudan', 'Suriname', 'Sweden', 'Switzerland', 'Syria', 'Tajikistan', 'Tanzania', 'Thailand',
                           'Timor-Leste', 'Togo', 'Tonga', 'Trinidad and Tobago', 'Tunisia', 'Turkmenistan', 'Tuvalu',
                           'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States of America',
                           'Uruguay', 'Uzbekistan', 'Vanuatu', 'Venezuela', 'Yemen', 'Zambia', 'Zimbabwe',
                           'Afghanistan', 'Angola', 'Azerbaijan', 'Belgium', 'Belize', 'Bolivia', 'Bulgaria', 'Chad',
                           'Chile', 'Costa Rica', 'Cyprus', 'Dominica', 'Egypt', 'France', 'Haiti', 'Iceland',
                           'Jamaica', 'Madagascar', 'Malawi', 'Namibia', 'Nauru', 'Netherlands', 'New Zealand',
                           'Nigeria', 'Oman', 'Poland', 'Qatar', 'Russia', 'Saint Kitts and Nevis', 'San Marino',
                           'Slovakia', 'Solomon Islands', 'South Africa', 'Turkey', 'Vietnam', 'Belarus', 'Colombia',
                           'Congo (Congo-Brazzaville)', 'Guinea', 'Holy See', 'Kazakhstan', 'Moldova', 'Mongolia',
                           'Peru', 'Romania', 'Iran', 'Mauritius', 'Liberia', 'Eswatini (fmr. "Swaziland")']
        try:
            self.df = self.df[self.df['Country'].isin(valid_countries)]
            return self.df
        except KeyError as e:
            raise RemoveError(f"Error removing wrong countries: {e}")

    def change_country_names(self):
        """
        Changes specified country names in the 'Country' column of the DataFrame
        in order to have shorter names.

        Returns
        -------
        pandas.DataFrame
            The DataFrame with specified country names changed.

        Raises
        ------
        RemoveError
            If there is an error changing country names.
        """
        replace_dict = {
            "Czechia (Czech Republic)": "Czechia",
            "Democratic Republic of the Congo": "R.D. Congo",
            "Myanmar (formerly Burma)": "Myanmar",
            "Congo (Congo-Brazzaville)": "Congo-Brazzaville",
            'Eswatini (fmr. "Swaziland")': "Eswatini"
        }
        try:
            self.df['Country'] = self.df['Country'].replace(replace_dict)
            return self.df
        except KeyError as e:
            raise RemoveError(f"Error changing country names: {e}")

    def remove_wrong_sentiment(self):
        """
        Removes rows with invalid 'sentiment' values from the DataFrame.

        Valid 'sentiment' values:
        - "positive"
        - "negative"
        - "neutral"

        Returns
        -------
        pandas.DataFrame
            The DataFrame with rows containing valid 'sentiment' values.

        Raises
        ------
        RemoveError
            If there is an error removing rows based on 'sentiment' values.
        """
        valid_sentiments = ["positive", "negative", "neutral"]
        try:
            self.df = self.df[self.df['sentiment'].isin(valid_sentiments)]
            return self.df
        except KeyError as e:
            raise RemoveError(f"Error removing wrong sentiments: {e}")
